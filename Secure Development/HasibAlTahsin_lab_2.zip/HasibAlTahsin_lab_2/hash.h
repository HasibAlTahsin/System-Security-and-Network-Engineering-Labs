/**
*
* @Name : hash.h
*
**/
#ifndef __HASH__
#define __HASH__

/*
1. Incompatible struct pointer declaration (Type safety issue)
Security Issue: CWE-843 (Access of Resource Using Incompatible Type)
Explanation:
    Inside the struct definition, the member is declared as: struct PairValue* Next;
    But there is NO prior declaration like:
    typedef struct PairValue PairValue;
    This creates a reference to a struct tag that is technically different from the typedef name 'PairValue'. 
    While it may compile, it can cause incompatible pointer type warnings and subtle bugs.
Impact:
    Integrity:       Type mismatch may cause undefined behavior
    Maintainability: Compiler warnings and unsafe design
*/
typedef struct {
    #define KEY_STRING_MAX 255

    char KeyName[KEY_STRING_MAX];
/*
2. Fixed-size buffer risk 
Security Issue: CWE-120 (Classic Buffer Overflow) 
Explanation:
   KeyName has fixed size (255 bytes).
   If external code copies a longer string using unsafe functions like strcpy(), it may overflow this buffer.
    Impact:
        Integrity:    Memory corruption
        Availability: Crash
*/

    int ValueCount;

    struct PairValue* Next;
       /* 
       BUG: Uses 'struct PairValue*' without proper forward typedef.
       Need to do:
            typedef struct PairValue PairValue;
            struct PairValue {
                ...
                PairValue* Next;
            };
       */
} PairValue;


/*
3. Fixed bucket size without automatic bounds enforcement
Security Issue: CWE-119 (Improper Restriction of Operations within the Bounds of a Memory Buffer)
Explanation:
    MAP_MAX is 128, so valid indexes are 0..127.
    If hash functions return a value outside this range and caller does not apply modulo (idx % MAP_MAX), 
    any access like data[idx] will cause out-of-bounds read/write.
Impact:
    Integrity:       Memory corruption
    Availability:    Crash
    Confidentiality: Possible memory disclosure
*/
typedef struct {

    #define MAP_MAX 128

    PairValue* data[MAP_MAX];

/*
4. Uninitialized pointer array risk
Security Issue: CWE-457 (Use of Uninitialized Variable)
Explanation:
   data[] must be initialized to NULL before use.
   If allocated with malloc() and not zeroed, data[] may contain garbage pointers.
   Dereferencing them causes undefined behavior.
Impact:
   Availability: Crash
   Integrity:    Memory corruption
*/

} HashMap;

HashMap* HashInit();
void HashAdd(HashMap *map, PairValue *value);
void HashDelete(HashMap *map, const char* key);
PairValue* HashFind(HashMap *map, const char* key);
void HashDump(HashMap *map);

#endif
