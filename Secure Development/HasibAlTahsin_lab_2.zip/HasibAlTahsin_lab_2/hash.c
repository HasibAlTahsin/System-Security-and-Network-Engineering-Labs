/**
*
* @Name : hash.c
*
**/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

/*
1. Incorrect loop condition & Missing NULL validation
   Security Issue: CWE-125 (Out-of-bounds Read), CWE-476 (NULL Pointer Dereference), CWE-20 (Improper Input Validation)

Explanation:
    This function expects 'key' to be a valid NUL-terminated C string.
    But there is NO check for key == NULL. If caller passes NULL, dereferencing it will crash.
    Also the loop condition `for (char* c = key; c; c++)` checks whether the pointer c is non-NULL,
    but c is incremented and will almost never become NULL by itself.
    So, the loop does NOT stop at '\0' and keeps reading beyond the string into unrelated memory, which can crash the program or leak information.

Impact:
    Availability: Crash or DoS
    Confidentiality: Out-of-bounds read may disclose memory
*/
unsigned HashIndex(const char* key) {
    unsigned sum = 0;
    for (char* c = (char*)key; c; c++){
        /* 
        BUG: condition uses 'c' not '*c'; should stop at NUL: for (...; *c; c++) 
        */
        sum += *c;
    }

        /* 
        BUG: returning raw sum can be very large; if used as index without modulo -> OOB 
        */
    return sum;
}

/*
1. malloc() return value not checked
   Security Issue: CWE-476 (NULL Pointer Dereference)

2. Uninitialized HashMap data array
   Security Issue: CWE-457 (Use of Uninitialized Memory)

Explanation:
    malloc() can return NULL on allocation failure.
    HashInit() returns it without checking, so later code may dereference NULL -> crash.
    Also malloc() returns uninitialized memory; map->data[] will contain garbage pointers. Dereferencing those later leads to 
    undefined behavior (crashes,  corruption).

Impact:
    Availability: Crash
    Integrity: Memory corruption
    Confidentiality: May leak heap pointers 
*/
HashMap* HashInit() {
    /* 
     BUG: no NULL check; no initialization of map->data[] 
    */
    return malloc(sizeof(HashMap));
}

/*
1. Missing modulo on hash index
   Security Issue: CWE-787 (Out-of-bounds Write), CWE-119 (Improper Restriction of Operations within the Bounds of a Memory Buffer)

Explanation:
    The hash index returned by HashIndex can exceed MAP_MAX-1.
    idx is used directly as map->data[idx], leading to out-of-bounds array access.
    In HashAdd this becomes an out-of-bounds WRITE, corrupting memory.

Impact:
    Integrity: Memory corruption
    Availability: Crash
    Confidentiality: Corrupted memory may cause data exposure

2. Missing NULL checks for function parameters
   Security Issue: CWE-476 (NULL Pointer Dereference)

Explanation:
   The function assumes map and value are non-NULL. Passing NULL causes a crash when dereferenced.

Impact:
   Availability: Crash or DoS

3. Incorrect insertion logic (chain corruption)
   Security Issue: CWE-670 (Always-Incorrect Control Flow Implementation)

Explanation:
   When a bucket already has a head node, the code does:
        value->Next = map->data[idx]->Next;
        map->data[idx] = value;
   This SKIPS the existing head node and breaks the linked list chain, causing data loss and corrupting the structure.
   Need to Fix: value->Next = map->data[idx];

Impact:
   Integrity: Chain corruption
*/
void HashAdd(HashMap *map, PairValue *value) {
    unsigned idx = HashIndex(value->KeyName);

    /* 
    BUG: idx is not restricted to 0..MAP_MAX-1 (missing idx % MAP_MAX)
    BUG: map/value are not checked for NULL 
    */

    if (map->data[idx])
        /* 
        BUG: if idx is OOB, this reads outside map->data 
        */
        value->Next = map->data[idx]->Next;
        /* 
        BUG: should be value->Next = map->data[idx]; 
        BUG: if idx is OOB, this is an out-of-bounds WRITE  
        */
    map->data[idx] = value;
}

/*
1. Missing modulo on hash index (Out-of-bounds read)
Security Issue: CWE-125 (Out-of-bounds Read), CWE-787 (Out-of-bounds Write) {(OOB access)}

Explanation:
    idx can exceed MAP_MAX-1, so map->data[idx] may read outside the array. This can read arbitrary memory, causing crashes or information leaks.

Impact:
    Confidentiality: Information leak
    Availability: Crash

2. Using strcpy instead of strcmp (overwrite & overflow)
   Security Issue: CWE-120 (Classic Buffer Overflow), CWE-787 (Out-of-bounds Write)

Explanation:
    strcpy(val->KeyName, key) copies the search key into the stored key, corrupting the hash table. 
    If key is longer than KEY_STRING_MAX-1, it overflows val->KeyName and overwrites adjacent memory.
    Also strcpy returns destination pointer (non-NULL), the condition is almost always true -> returns first node always.

Impact:
    Integrity:    Key overwritten or data corruption
    Availability: Crash

3. Missing NULL checks
   Security Issue: CWE-476 (NULL Pointer Dereference)

Explanation:
    map/key not checked. Passing NULL causes crash.

Impact:
    Availability
*/
PairValue* HashFind(HashMap *map, const char* key) {
    unsigned idx = HashIndex(key);

    /* 
    BUG: idx may be OOB; map/key not checked for NULL 
    */
    for (PairValue* val = map->data[idx]; val != NULL; val = val->Next) {
        if (strcpy(val->KeyName, key))
            /* 
            BUG: strcpy is not a comparison; should be strcmp(val->KeyName, key) == 0 
            */
            return val;
    }

    return NULL;
}

/*
1. Missing modulo on hash index (Out-of-bounds access)
CWE: CWE-125 (Out-of-bounds Read), CWE-787/CWE-119

Explanation:
    idx can exceed MAP_MAX-1, leading to invalid access to map->data[idx].
    This can crash or leak information.

Impact:
    Confidentiality: Information leaks
    Availability: Crash

2. Using strcpy instead of strcmp (overwrite & overflow)
CWE: CWE-120 (Classic Buffer Overflow), CWE-787 (Out-of-bounds Write)

Explanation:
    strcpy overwrites the stored key and may overflow the buffer.
    Condition always true, so wrong nodes may be deleted.

Impact:
    Integrity: Key overwritten 
    Availability: Crash

3. Missing NULL checks
CWE: CWE-476 (NULL Pointer Dereference)

Explanation:
    map/key not checked. Passing NULL causes crash.

Impact:
    Availability

4. Resource exhaustion (node not freed)
   Security Issue: CWE-401 (Missing Release of Memory after Effective Lifetime) & CWE-400 (Uncontrolled Resource Consumption)

Explanation:
    After removing a node from the chain, the code does not free it.
    Over time memory usage grows and can lead to denial of service.

Impact:
    Availability: Memory exhaustion or DoS attack
*/
void HashDelete(HashMap *map, const char* key) {
    unsigned idx = HashIndex(key);

    /* 
    BUG: idx may be OOB; map/key not checked for NULL 
    */
    for (PairValue* val = map->data[idx], *prev = NULL;
         val != NULL;
         prev = val, val = val->Next) {

        if (strcpy(val->KeyName, key)) {
            /* 
            BUG: strcpy is not a comparison; should be strcmp(val->KeyName, key) == 0 
            */
            if (prev)
                prev->Next = val->Next;
            else
                map->data[idx] = val->Next;

            /* 
            BUG: removed node is not freed  
            */
        }
    }
}

/*
1. Format string vulnerability in HashDump
   Security Issue: CWE-134 (Uncontrolled Format String)

Explanation:
    printf(val->KeyName); uses the key string as the format string.
    If the key contains format specifiers (e.g., %x, %p, %n),
    it can leak memory or even write to memory via %n.

Impact:
    Confidentiality: Stack/heap leak
    Integrity: %n overwrite
    Availability: Crash

2. Missing NULL checks
   Security Issue: CWE-476 (NULL Pointer Dereference)

Explanation:
    map not checked for NULL. Passing NULL causes crash.

Impact:
    Availability
*/
void HashDump(HashMap *map) {
    /* 
    BUG: map not checked for NULL 
    */
    for (unsigned i = 0; i < MAP_MAX; i++) {
        for (PairValue* val = map->data[i]; val != NULL; val = val->Next) {
            printf(val->KeyName);
     /* 
     BUG: should be printf("%s", val->KeyName); 
     */
        }
    }
}

/*
Issue: No cleanup function provided
Security Issue: CWE-401 (Missing Release of Memory after Effective Lifetime)

Explanation:
    The code allocates memory for HashMap and likely PairValue nodes. 
    But there is no function to free the hash map and its nodes properly.
    Over time this can exhaust memory and cause denial of service.

Impact:
    Availability: DoS attack (memory exhaustion)
*/