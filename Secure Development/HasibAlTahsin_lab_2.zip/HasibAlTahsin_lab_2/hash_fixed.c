/**
*
* @Name : hash_fixed.c
*
**/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

/*
1. Incorrect loop condition
Fix to Remove the Problem:
    Validate input pointer: if (key == NULL) return 0;
    Iterate over characters until '\0': for (...; *c != '\0'; ++c)
    Reduce hash using % MAP_MAX
Fix Works on:
    Prevents NULL pointer dereference (CWE-476: NULL Pointer Dereference)
    Stops at string boundary → no out-of-bounds read (CWE-125: Out-of-bounds Read)
    Ensures index always inside 0..MAP_MAX-1 (prevents OOB access; read/write are CWE-125/CWE-787)
Hardening:
    Always validate input pointers
    Use bounded iteration
    Always constrain computed indexes
*/
static unsigned HashIndexSafe(const char* key) {
    if (key == NULL) {
        return 0;
    }

    unsigned sum = 0;

    for (const unsigned char *c = (const unsigned char*)key; *c != '\0'; ++c) {
        sum += (unsigned)(*c);
    }

    return sum % MAP_MAX;
}

/*
1. Uninitialized HashMap data array
Fix to Remove the Problem:
    Use calloc(1, sizeof(HashMap)) to zero-initialize
    Check allocation result

Fix Works on:
    All bucket pointers start as NULL
    Prevents garbage pointer dereference (CWE-457: Use of Uninitialized Variable)

Hardening:
    Always zero memory for structs containing pointers
    Handle out-of-memory conditions safely
*/
HashMap* HashInit(void) {
    HashMap *map = (HashMap*)calloc(1, sizeof(HashMap));
    if (map == NULL) {
        fprintf(stderr, "HashInit: out of memory\n");
        exit(EXIT_FAILURE);
    }
    return map;
}

/*
1. Missing modulo on hash index
Fix to Remove the Problem:
    Use HashIndexSafe() which already applies % MAP_MAX
Fix Works on:
    Prevents out-of-bounds access on data[] (CWE-125: Out-of-bounds Read, CWE-787: Out-of-bounds Write)
Hardening:
    Never trust computed indexes
    Constrain indexes before array access

2. Missing NULL checks
Fix to Remove the Problem:
    if (map == NULL || value == NULL) return;
Fix Works on:
    Prevents NULL pointer dereference (CWE-476: NULL Pointer Dereference)
Hardening:
    Validate all external inputs
    Fail safely

3. Incorrect insertion logic
Fix to Remove the Problem:
    Proper head insertion:
    value->Next = map->data[idx];
    map->data[idx] = value;
Fix Works on:
    Preserves existing chain
    Prevents data loss (CWE-670: Always-Incorrect Control Flow Implementation)
Hardening:
    Use consistent linked list insertion pattern
    Add collision test cases

4. Defense-in-depth: enforce NUL termination
Fix to Remove the Problem:
    value->KeyName[KEY_STRING_MAX - 1] = '\0';
Fix Works on:
    Prevents over-read if external input lacked terminator (CWE-170: Improper Null Termination)
Hardening:
    Always enforce terminators for fixed-size buffers
    Prefer bounded copy + manual terminator
*/
void HashAdd(HashMap *map, PairValue *value) {
    if (map == NULL || value == NULL) {
        return;
    }

    /* Defense-in-depth */
    value->KeyName[KEY_STRING_MAX - 1] = '\0';

    unsigned idx = HashIndexSafe(value->KeyName);

    /* Proper head insertion */
    value->Next = map->data[idx];
    map->data[idx] = value;
}

/*
1. Missing modulo on hash index
Fix to Remove the Problem:
    Use HashIndexSafe(key)
Fix Works on:
    Index always within bounds (prevents OOB access) (CWE-787: Out-of-bounds Write)
Hardening:
    Keep index generation centralized

2. Using strcpy instead of strcmp
Fix to Remove the Problem:
    Use strcmp(val->KeyName, key) == 0
Fix Works on:
    Proper comparison without modifying stored data
    Avoids overflow/corruption caused by strcpy (CWE-120: Classic Buffer Overflow, CWE-787: Out-of-bounds Write)
Hardening:
    Never use strcpy for comparisons
    Prefer bounded string operations

3. Missing NULL checks
Fix to Remove the Problem:
    if (map == NULL || key == NULL) return NULL;
Fix Works on:
    Prevents crash from invalid pointer (CWE-476: NULL Pointer Dereference)
Hardening:
    Validate pointers at function entry
*/
PairValue* HashFind(HashMap *map, const char* key) {
    if (map == NULL || key == NULL) {
        return NULL;
    }

    unsigned idx = HashIndexSafe(key);

    for (PairValue *val = map->data[idx]; val != NULL; val = val->Next) {
        if (strcmp(val->KeyName, key) == 0) {
            return val;
        }
    }

    return NULL;
}

/*
1. Missing modulo on hash index
Fix to Remove the Problem:
    Use HashIndexSafe(key)
Fix Works on:
    Prevents OOB access (CWE-125: Out-of-bounds Read, CWE-787: Out-of-bounds Write)
Hardening:
    Constrain all indexes before use

2. Using strcpy instead of strcmp
Fix to Remove the Problem:
    Use strcmp(val->KeyName, key) == 0
Fix Works on:
    Avoids overwriting key and buffer overflow (CWE-120: Classic Buffer Overflow, CWE-787: Out-of-bounds Write)
Hardening:
    Avoid unsafe string copy APIs

3. Missing NULL checks
Fix to Remove the Problem:
    if (map == NULL || key == NULL) return;
Fix Works on:
    Prevents NULL dereference (CWE-476: NULL Pointer Dereference)
Hardening:
    Validate all external inputs at function entry

4. Memory leak
Fix to Remove the Problem:
    free(val);
    return after deletion
Fix Works on:
    Releases heap memory
    Prevents resource exhaustion / DoS over time (CWE-401: Missing Release of Memory after Effective Lifetime)
Hardening:
    Clearly document ownership of PairValue
    Provide a HashFree() cleanup function for the full table
*/
void HashDelete(HashMap *map, const char* key) {
    if (map == NULL || key == NULL) {
        return;
    }

    unsigned idx = HashIndexSafe(key);

    PairValue *prev = NULL;
    PairValue *val  = map->data[idx];

    while (val != NULL) {
        if (strcmp(val->KeyName, key) == 0) {
            if (prev != NULL) {
                prev->Next = val->Next;
            } else {
                map->data[idx] = val->Next;
            }

            free(val);
            return;
        }

        prev = val;
        val  = val->Next;
    }
}

/*
1. Format string vulnerability
Fix to Remove the Problem:
    Use constant format string: printf("%.*s\n", KEY_STRING_MAX-1, val->KeyName);
Fix Works on:
    Prevents attacker-controlled format string execution (CWE-134: Use of Externally-Controlled Format String)
Hardening:
    Never pass variable as format string
    Compile with -Wformat -Werror=format-security

2. Missing NULL checks
Fix to Remove the Problem:
    if (map == NULL) return;
Fix Works on:
    Prevents crash (CWE-476: NULL Pointer Dereference)
Hardening:
    Validate all external inputs
    Fail safely
*/
void HashDump(HashMap *map) {
    if (map == NULL) {
        return;
    }

    for (unsigned i = 0; i < MAP_MAX; i++) {
        for (PairValue *val = map->data[i]; val != NULL; val = val->Next) {
            printf("%.*s\n", KEY_STRING_MAX - 1, val->KeyName);
        }
    }
}