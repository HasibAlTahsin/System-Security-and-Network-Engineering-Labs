/**
*
* @Name : hash_fixed.h
*
**/
#ifndef __HASH_FIXED__
#define __HASH_FIXED__

/*
1. Incompatible struct pointer declaration (Type safety issue)
Security Issue: CWE-843 (Access of Resource Using Incompatible Type)
Fix to Remove the Problem:
    Use a named struct + forward declaration so the self-referential pointer type is correct:
      typedef struct PairValue PairValue;
      struct PairValue { ... PairValue *Next; };
Fix Works on:
    Eliminates incompatible pointer type warnings
    Ensures Next points to the correct PairValue type (type-safe)
Hardening:
    Always forward-declare self-referential structs
    Compile with -Wall -Wextra and treat warnings as errors in CI
*/

/* 
Make constants global (not inside struct) 
*/
#define KEY_STRING_MAX 255
#define MAP_MAX 128

/* 
Forward declare 
*/
typedef struct PairValue PairValue;

/*
2. Fixed-size buffer risk
Security Issue: CWE-120 (Classic Buffer Overflow)
Fix to Remove the Problem:
    Keep fixed-size buffer but enforce safer usage in implementation:
      Avoid strcpy/strcat
      Ensure NUL termination (e.g., KeyName[KEY_STRING_MAX-1] = '\0')
Fix Works on:
    Prevents buffer overflow when keys are handled safely
Hardening:
    Use bounded copy/print functions + manual terminator
    Validate/limit input key length before copying
*/

/* 
FIXED: define as named struct so Next is correct type 
*/
struct PairValue {
    char KeyName[KEY_STRING_MAX];
    int  ValueCount;
    PairValue *Next;   /* FIX: correct self-referential pointer type */
};


/*
3. Fixed bucket size without automatic bounds enforcement
Security Issue: CWE-119 (Improper Restriction of Operations within the Bounds of a Memory Buffer)
Fix to Remove the Problem:
    Always constrain computed indexes in implementation:
      idx = hash(...) % MAP_MAX;
Fix Works on:
    Prevents out-of-bounds access to data[] (avoids OOB read/write)
Hardening:
    Centralize index calculation in one safe helper function
    Add tests for boundary/collision cases (many keys same bucket)
*/

/*
4. Uninitialized pointer array risk
Security Issue: CWE-457 (Use of Uninitialized Variable)
Fix to Remove the Problem:
    Ensure HashMap is zero-initialized in HashInit() (use calloc or memset)
    so data[] starts as NULL.
Fix Works on:
    Prevents garbage pointer dereference by guaranteeing NULL pointers initially
Hardening:
    Prefer calloc for structs containing pointer arrays
    Document that data[] must be NULL-initialized before use
*/
typedef struct {
    PairValue *data[MAP_MAX];
} HashMap;

/* 
API 
*/
HashMap* HashInit(void);
void HashAdd(HashMap *map, PairValue *value);
void HashDelete(HashMap *map, const char* key);
PairValue* HashFind(HashMap *map, const char* key);
void HashDump(HashMap *map);

#endif